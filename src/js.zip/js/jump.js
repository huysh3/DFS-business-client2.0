$('#basic-skills').click(function() {
  window.location.href = 'index-tab1'
})

$('#experience').click(function() {
  window.location.href = 'index-tab3.html'
})

$('#coffee').click(function() {
  window.location.href = 'index-tab10.html'
})

$('#contact-me').click(function() {
  window.location.href = 'index-tab11.html'
})
